For the project to correctly link header files from the SDK, the
firmware_updater folder should be placed at the same depth in SDK folder
hierarchy as the other SDK projects.

If unsure, place it in the \source_code\projects\nrfgo_sdk folder.
